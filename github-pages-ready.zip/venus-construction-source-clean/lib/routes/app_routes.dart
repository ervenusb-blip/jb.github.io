class AppRoutes {
  static const String home = '/';
  static const String marketPrices = '/market-prices';
  static const String priceCalculator = '/price-calculator';
}
