import 'package:flutter/material.dart';

class PriceHistoryBottomSheet extends StatelessWidget {
  final String material;

  PriceHistoryBottomSheet({required this.material});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text("Price History - $material", style: TextStyle(fontSize: 20)),
          ListTile(title: Text("01-Aug-2025"), subtitle: Text("₹ 1000")),
          ListTile(title: Text("15-Aug-2025"), subtitle: Text("₹ 1020")),
          ListTile(title: Text("25-Aug-2025"), subtitle: Text("₹ 980")),
        ],
      ),
    );
  }
}
