import 'package:flutter/material.dart';

class CategoryFilterChips extends StatelessWidget {
  final List<String> categories;
  final Function(String) onSelected;

  CategoryFilterChips({required this.categories, required this.onSelected});

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8.0,
      children: categories.map((category) {
        return ChoiceChip(
          label: Text(category),
          selected: false,
          onSelected: (_) => onSelected(category),
        );
      }).toList(),
    );
  }
}
