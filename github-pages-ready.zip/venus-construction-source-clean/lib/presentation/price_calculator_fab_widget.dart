import 'package:flutter/material.dart';

class PriceCalculatorFAB extends StatelessWidget {
  final VoidCallback onPressed;

  PriceCalculatorFAB({required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton(
      child: Icon(Icons.calculate),
      onPressed: onPressed,
    );
  }
}
