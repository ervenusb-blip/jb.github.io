# 🏗️ Venus Construction App

Welcome to the **Venus Construction App** repository.  
This project showcases the profile, services, and portfolio of *Venus Construction*, a Chennai-based civil construction firm with over 30 years of experience.

---

## 🌟 Features

- Responsive **homepage UI** with company introduction, services, and contact details
- **Project portfolio** with image previews and grid-based layout
- Real-time **Chennai construction material prices** (coming soon)
- **Search, filter, and price card widgets** for material comparison
- **Interactive calculator** with floating action button
- Deployed live via **GitHub Pages**

---

## 🌐 Live Demo

👉 Visit the live site here: [ervenusb-blip.github.io](https://ervenusb-blip.github.io)

---

## 📂 Project Structure

```
.
├── index.html        # Homepage
├── styles.css        # Global stylesheet
├── script.js         # JavaScript interactivity
├── assets/           # Images and static assets
├── CHANGELOG.md      # Project changelog
└── README.md         # Project documentation
```

---

## 🚀 Getting Started

1. Clone the repository:
   ```bash
   git clone https://github.com/ervenusb-blip/jb.github.io.git
   ```

2. Navigate to the folder:
   ```bash
   cd jb.github.io
   ```

3. Open `index.html` in your browser or serve locally with a live server.

---

## 📅 Changelog

Check out the full [CHANGELOG.md](./CHANGELOG.md) for detailed updates.

---

## 📞 Contact

**Venus Construction**  
21, Vanniar St, Minor Trustpuram, Choolaimedu, Chennai, Tamil Nadu – 600094  
📱 Phone: +91 73388 05997  

---

© 2025 Venus Construction. All rights reserved.
