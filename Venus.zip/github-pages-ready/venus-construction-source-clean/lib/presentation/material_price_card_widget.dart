import 'package:flutter/material.dart';

class MaterialPriceCard extends StatelessWidget {
  final String material;
  final double price;

  MaterialPriceCard({required this.material, required this.price});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(8.0),
      child: ListTile(
        title: Text(material),
        subtitle: Text("₹ $price per unit"),
      ),
    );
  }
}
