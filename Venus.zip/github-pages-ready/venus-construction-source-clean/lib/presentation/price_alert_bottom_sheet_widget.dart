import 'package:flutter/material.dart';

class PriceAlertBottomSheet extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text("Set Price Alert", style: TextStyle(fontSize: 20)),
          TextField(decoration: InputDecoration(labelText: "Enter material name")),
          TextField(decoration: InputDecoration(labelText: "Enter target price")),
          SizedBox(height: 10),
          ElevatedButton(onPressed: () {}, child: Text("Save Alert"))
        ],
      ),
    );
  }
}
