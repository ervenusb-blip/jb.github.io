import 'package:flutter/material.dart';

class ChennaiMarketPrices extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Chennai Market Prices")),
      body: Center(child: Text("Market prices list will appear here")),
    );
  }
}
