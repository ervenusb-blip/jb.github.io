document.addEventListener("DOMContentLoaded", () => {
  console.log("Venus Construction site loaded successfully!");
});
