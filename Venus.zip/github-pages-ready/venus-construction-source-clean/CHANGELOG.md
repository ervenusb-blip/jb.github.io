# 📖 Changelog

All notable changes to this project will be documented in this file.

---

## 🚀 [Unreleased]

- Upcoming integration of **real-time Chennai construction material prices**
- Addition of **search & filter enhancements** for project listings
- Implementation of **user enquiry form** with email notifications

---

## 📅 Aug 29, 2025 – Venus Construction App

- Implemented **Homepage UI** with company introduction, services section, and contact card
- Integrated **project portfolio screen** with grid-based layout and image preview modal
- Added **GitHub Pages deployment support** for live preview at [ervenusb-blip.github.io](https://ervenusb-blip.github.io)
- Configured **responsive design** with mobile-friendly navigation menu
- Introduced **assets folder structure** for images, icons, and documents

---

## 📅 Aug 28, 2025 – Market Prices Module

- Implemented **Chennai Market Prices screen** with real-time construction material pricing
- Created comprehensive **widget system** for search, filtering, and price cards
- Added **routing configuration** with tab bar navigation and floating action button calculator
